def hello():
	print("Ciao mondo!")
